<?php
$message_ins = '
<!DOCTYPE html>
<html>
<header>
    <meta charset="utf-8">
   </header>
<body>
<p>Bienvenue,</p>
</br>
</br>
<p>Pour confirmer la création de votre compte veuillez cliquer sur le lien ci dessous.</p>
</br>
</br>

<a href="http://localhost/wiki/activation.php?prenom=">Cliquez ici pour activer votre compte!</a>


<p>--------------------------------------------------------------------</p>
<p>Ceci est un mail automatique, Merci de ne pas y répondre.</p>

</body>
</html>';
