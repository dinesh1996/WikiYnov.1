<div class="contenaire">
    <div id="contenaire_accueil">
        <h1>Inscription</h1>
        <form action="#" method="post">
            <input name="prenom" type="text" placeholder="Prenom"></br>
            <input name="nom" type="text" placeholder="Nom"></br>
            <input name="password" type="password" placeholder="Password"></br>
            <div>
                <button name="inscription" type="submit">S'inscrire</button>
            </div>
        </form>
    </div>
</div>
<?php require 'includes/footer.php';